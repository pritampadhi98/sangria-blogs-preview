import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import BlogClip from "./components/BlogClip";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/blog" element={<BlogClip />} />
      </Routes>
    </Router>
  );
}

export default App;

import React from "react";

const BlogClip = () => {
  return (
    <div>
      <h1>Welcome to Reactiv Blog Clip author by sangria</h1>
      <p>This is a lightweight micro-app for a blog preview.</p>
    </div>
  );
};

export default BlogClip;
